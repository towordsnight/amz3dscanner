import open3d as o3d
import numpy as np
import os

def run_icp_registration(source, target, voxel_size=0.005, threshold=0.02):
    # === 降采样和法向估计（为 ICP 做准备）===
    source_down = source.voxel_down_sample(voxel_size)
    target_down = target.voxel_down_sample(voxel_size)
    source_down.estimate_normals()
    target_down.estimate_normals()

    # === 初始变换矩阵（单位矩阵）===
    init_transform = np.identity(4)

    # === 执行 ICP（点到面）===
    result_icp = o3d.pipelines.registration.registration_icp(
        source_down, target_down, threshold, init_transform,
        o3d.pipelines.registration.TransformationEstimationPointToPlane()
    )
    print("✅ ICP 完成，fitness:", result_icp.fitness)
    return result_icp.transformation


if __name__ == "__main__":
    input_dir = "./results"
    bottom_path = os.path.join(input_dir, "green_bottom_stand_cropped.ply")
    top_path = os.path.join(input_dir, "green_top_cropped.ply")
    output_path = os.path.join(input_dir, "stacked_icp_merged.ply")

    # === 读取点云 ===
    bottom = o3d.io.read_point_cloud(bottom_path)
    top = o3d.io.read_point_cloud(top_path)

    if bottom.is_empty() or top.is_empty():
        print("❌ 点云读取失败，请检查路径")
        exit(1)

    # === 使用 ICP 对 bottom 进行配准 ===
    print("🚧 正在执行 ICP 配准...")
    transformation_icp = run_icp_registration(bottom, top)
    bottom.transform(transformation_icp)

    # === 合并点云并融合重叠区域（使用较小体素尺寸）===
    print("🔁 正在合并并融合重叠点...")
    merged = top + bottom
    merged = merged.voxel_down_sample(voxel_size=0.001)  # 小体素值融合重叠区域

    # === 去除噪声点 ===
    cl, ind = merged.remove_statistical_outlier(nb_neighbors=30, std_ratio=2.0)
    clean_merged = merged.select_by_index(ind)

    # === 保存结果 ===
    o3d.io.write_point_cloud(output_path, clean_merged)
    print(f"✅ 已保存合并点云：{output_path}")
