import cv2
import numpy as np 
import open3d as o3d 

class Camera:
    def __init__(self, fx, fy, cx, cy):
        self.fx = fx
        self.fy = fy
        self.cx = cx
        self.cy = cy

def getPosition(cam, depth, m, n):

    h, w = depth.shape
    if not (0 <= m < h and 0 <= n < w):
        return (0.0, 0.0, 0.0)
    
    z = depth[m, n] / 1000.0
    x = (n - cam.cx) * z / cam.fx
    y = (m - cam.cy) * z / cam.fy
    return (x, y, z)

def getColor(rgb, m, n):

    h, w, _ = rgb.shape
    if not (0 <= m < h and 0 <= n < w):
        return [0.0, 0.0, 0.0]

    r = rgb[m, n, 2] / 255.0
    g = rgb[m, n, 1] / 255.0
    b = rgb[m, n, 0] / 255.0
    return [r, g, b]

