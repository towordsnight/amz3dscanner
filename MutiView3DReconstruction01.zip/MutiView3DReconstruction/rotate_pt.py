import open3d as o3d
import numpy as np
import os

def rotate_to_stand(input_path, output_path):
    # 读取点云
    pcd = o3d.io.read_point_cloud(input_path)
    if pcd.is_empty():
        print("❌ 点云读取失败，请检查路径")
        return

    # 绕 X 轴旋转 -90°
    standup_transform = np.array([
        [1, 0,  0, 0],
        [0, 0, -1, 0],
        [0, 1,  0, 0],
        [0, 0,  0, 1]
    ])
    pcd.transform(standup_transform)

    # 保存旋转后的点云
    o3d.io.write_point_cloud(output_path, pcd)
    print(f"✅ 已保存旋转后的点云：{output_path}")

if __name__ == "__main__":
    input_path = "./results/green_bottom.ply"
    output_path = "./results/green_bottom_stand.ply"
    rotate_to_stand(input_path, output_path)
