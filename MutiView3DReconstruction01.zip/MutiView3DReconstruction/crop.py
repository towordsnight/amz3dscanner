import open3d as o3d
import numpy as np
import os

# 1. 加载点云
input_dir = "./results"
bottom_path = os.path.join(input_dir, "green_top.ply")
pcd = o3d.io.read_point_cloud(bottom_path)
output_path = os.path.join(input_dir, "cropped.ply")

# 2. 可选：降采样（减少点数量，去除高频噪声）
pcd = pcd.voxel_down_sample(voxel_size=0.002)

# 3. 可选：去除离群点（孤立噪点）
pcd, ind = pcd.remove_statistical_outlier(nb_neighbors=30, std_ratio=1.0)
# pcd, ind = pcd.remove_radius_outlier(nb_points=16, radius=0.01)

# 4. 手动设置一个立方体范围，裁剪出你想要保留的盒子部分
# 你需要自己设置合适的坐标范围 ↓↓↓↓↓
min_bound = np.array([-0.05, -0.05, -0.05])
max_bound = np.array([0.05, 0.05, 0.05])
aabb = o3d.geometry.AxisAlignedBoundingBox(min_bound, max_bound)
box_only = pcd.crop(aabb)

# 5. 可视化查看结果
o3d.visualization.draw_geometries([box_only], window_name="裁剪后的盒子")

# 6. 保存处理后结果
o3d.io.write_point_cloud(output_path, box_only)
